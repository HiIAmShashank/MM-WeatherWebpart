export declare const configurations: {
    APIStatusValid: string;
    APIStatusInvalid: string;
    APIDescriptionInvalidLocation: string;
    APIDescriptionInvalidAPIKey: string;
    APIDescriptionLocationNotFound: string;
    APIDescriptionLocationType: string;
    APIDescriptionUnits: string;
    WeatherAPI: string;
    APIValidation: string;
    Metric: string;
    Imperial: string;
    City: string;
    Zip: string;
    CardImageLink: string;
};
//# sourceMappingURL=constants.d.ts.map