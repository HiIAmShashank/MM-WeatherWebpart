export declare function capitalizeAllFirstLetters(text: string): string;
//# sourceMappingURL=utils.d.ts.map