import { Version } from '@microsoft/sp-core-library';
import { IPropertyPaneConfiguration } from '@microsoft/sp-property-pane';
import { BaseClientSideWebPart, WebPartContext } from '@microsoft/sp-webpart-base';
export interface IWeatherWebPartProps {
    APIKey: string;
    location: string;
    temperatureUnits: string;
    context: WebPartContext;
    errorMessage: string;
    isVerified: boolean;
    cityOrZip: string;
}
export default class WeatherWebPart extends BaseClientSideWebPart<IWeatherWebPartProps> {
    private temperatureUnits;
    private cityOrZip;
    render(): void;
    protected onDispose(): void;
    protected get dataVersion(): Version;
    protected getPropertyPaneConfiguration(): IPropertyPaneConfiguration;
}
//# sourceMappingURL=WeatherWebPart.d.ts.map