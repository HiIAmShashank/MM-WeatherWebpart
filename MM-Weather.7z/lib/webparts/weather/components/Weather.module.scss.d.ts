declare const styles: {
    weather: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    errorMessage: string;
    link: string;
    weatherImage: string;
    blogWrapper: string;
    blogCard: string;
    cardImg: string;
    cardDetails: string;
    cardText: string;
    readMore: string;
    detailsParent: string;
    details: string;
};
export default styles;
//# sourceMappingURL=Weather.module.scss.d.ts.map