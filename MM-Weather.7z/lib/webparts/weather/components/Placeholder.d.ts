/// <reference types="react" />
import { IPlaceHolderProps } from "./IPlaceHolderProps";
export declare const Placeholder: (props: IPlaceHolderProps) => JSX.Element;
//# sourceMappingURL=Placeholder.d.ts.map