/// <reference types="react" />
import { IWeatherProps } from "./IWeatherProps";
export declare const Weather: (props: IWeatherProps) => JSX.Element;
//# sourceMappingURL=Weather.d.ts.map