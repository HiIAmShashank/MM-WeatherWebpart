import { IApiResponse, IWeatherInformation } from "../models/models";
export declare class service {
    checkAPIKey: (apiKey: string) => Promise<IApiResponse>;
    getWeatherInformation: (location: string, APIKey: string, units: string, type: string) => Promise<IWeatherInformation>;
}
//# sourceMappingURL=service.d.ts.map