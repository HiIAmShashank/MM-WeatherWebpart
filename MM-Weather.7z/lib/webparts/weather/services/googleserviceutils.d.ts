export declare const loadMapApi: () => HTMLScriptElement;
//# sourceMappingURL=googleserviceutils.d.ts.map